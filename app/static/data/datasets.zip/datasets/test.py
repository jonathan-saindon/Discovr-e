import geocoder
import csv
import json

basepath = ""
categories = json.load(open(basepath + "categories.json", 'r'))
count = 0

def getCategory(tag, text):
	if tag != None and text != None:
		subcats = categories[tag]
		for subcat in subcats:
			keywords = subcats[subcat]
			for keyword in keywords:
				if keyword.lower().encode("utf-8") in text.lower().encode("utf-8"):
					return subcat
	return None

with open(basepath + "canada_heritage.csv", 'r') as data_file:
	data = csv.reader(data_file, dialect="excel", delimiter=",")
	next(data)
	tag = "patrimony"
	for elem in data:
		cat = getCategory(tag, elem[2] + " " + elem[8])
		if cat == None:
			count += 1
			print(elem[2])
			print(elem[8])
			print()

#print("Categories-Batiments: " + str(categories["patrimony"]["batiment"]))
print("Count: " + str(count))