import json
import xml.etree.ElementTree as ET

categories = {}
output_file = "attraits_categories.json"

with open("attraitsQc.xml", 'r') as xml_file:
	data = ET.parse(xml_file).getroot()
	for elem in data.findall('ETABLISSEMENT'):
	
		types = elem.find('ETBL_TYPES')
		
		if (types != None and len(types) > 0):
			type = types[0]
			
			id = str(type.find('ETBL_TYPE_ID').text)
			name = type.find('ETBL_TYPE_FR').text
			
			if (id != None):
				try:
					categories[id]
				except KeyError:
					categories[id] = name
					

#print(categories)
with open(output_file, "w") as f:
	f.write(json.dumps(categories, ensure_ascii=False))